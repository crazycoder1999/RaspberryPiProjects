#!/bin/bash

onError() {
	echo "Something Went Wrong...";
	exit 1;
}

config=/tmp/actions.txt
echo $config
sudo rm $config
sudo fdisk -l | grep "^/dev/sd">> $config 

if [ ! -f $config ]; then
	onError
fi

fstype=""

grep -q "FAT" $config
if [ $? -eq 0 ]; then
	echo "FAT";
	fstype="vfat";
fi

grep -q "NTFS" $config 
if [ $? -eq 0 ]; then
	echo "NTFS";
	fstype="ntfs-3g";
fi

if [ "$fstype" = "" ]; then 
	onError;
fi

devFile=$(awk '{print $1;}' $config)
echo "$devFile FS: $fstype";
sudo mount -t $fstype -o uid=pi,gid=pi $devFile /media

