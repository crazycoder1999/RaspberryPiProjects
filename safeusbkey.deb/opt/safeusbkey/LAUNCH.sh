#!/bin/bash

/opt/safeusbkey/findDrive2.sh
cd /opt/safeusbkey/OmegaWebExplorer
/usr/bin/nodejs /opt/safeusbkey/OmegaWebExplorer/app.js
