#!/bin/bash

/opt/safeusbkey/findDrive.sh
cd /opt/safeusbkey/OmegaWebExplorer
/usr/bin/nodejs /opt/safeusbkey/OmegaWebExplorer/app.js
